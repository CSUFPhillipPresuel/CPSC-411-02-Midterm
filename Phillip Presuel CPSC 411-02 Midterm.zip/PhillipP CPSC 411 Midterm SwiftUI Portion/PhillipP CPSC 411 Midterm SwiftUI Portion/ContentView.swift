//
//  ContentView.swift
//  PhillipP CPSC 411 Midterm SwiftUI Portion
//
//  Created by ana presuel on 3/23/20.
//  Copyright © 2020 Phillip Presuel. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @State var tapCount = 0
    
    var body: some View {
        // Question 1
//        Text("Hello World")
//        .padding()
//            .background(Color.red)
//        .padding()
//            .background(Color.blue)
//        .padding()
//        .padding()
//            .background(Color.green)
        
        // Question 2
//        Text("Live long and prosper")
//            .frame(width: 200, height: 200)
//            .background(Color.red)
        
        // Question 3
//        NavigationView {
//            Form {
//                Section {
//                    Text("Hello, world")
//                    Text("Hello, world")
//                }
//            }.navigationBarTitle("SwiftUI")
//        }
        
        // Question 4 & 5
        Button(action: { self.tapCount += 1}) {
            Text("Tap Count: \(self.tapCount)")
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
